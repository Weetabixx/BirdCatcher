from django.apps import AppConfig


class TwitterStreamConfig(AppConfig):
    name = 'twitter_stream'
